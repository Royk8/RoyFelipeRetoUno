import java.io.IOException;

public class Inventory {

    public static void main(String[] args) throws IOException {
        Menu start = new Menu();
        start.menu();
    }
}
